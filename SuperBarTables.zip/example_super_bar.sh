perl SuperBarTables.pl example_super_bar.csv 4.5 6 12 1 6.0,8.0,10.0,12.0 >smoothing.tex

